<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('user_roles', function (Blueprint $table) { $table->foreignUuid('user_id')->constrained()->cascadeOnDelete(); $table->foreignUuid('role_id')->constrained()->cascadeOnDelete(); $table->primary(['user_id','role_id']); });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_roles');
    }
};
