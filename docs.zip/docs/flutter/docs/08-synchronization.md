# Flutter — 08. Motor de Sincronização

## Componentes

- SyncQueue
- SyncWorker
- LocalRepository
- RemoteRepository
- AttachmentUploader
- SyncConflictHandler

## Fila

Cada item deve possuir:

- event_id;
- entidade;
- entidade_id;
- operação/tipo;
- payload;
- criado_em;
- tentativas;
- próximo_retry;
- status;
- erro;
- versão de schema.

## Ordem

Respeitar dependências entre eventos quando existirem. Exemplo: não sincronizar `DELIVERY_COMPLETED` antes de garantir que a criação/atribuição da entrega seja conhecida pelo servidor ou que o evento traga contexto suficiente.

## Retry

Usar backoff. Não entrar em loop infinito agressivo.

## Duplicidade

O mesmo `event_id` pode ser reenviado sem duplicar o efeito no servidor.

## Anexos

Upload de fotos deve ser retomável e separado do evento quando necessário. O evento pode ficar em estado aguardando mídia se a regra exigir a evidência antes da conclusão.
